<?php
/*
* Workday - A time clock application for employees
* Email: official.codefactor@gmail.com
* Version: 1.1
* Author: Brian Luna
* Copyright 2020 Codefactor
*/
namespace App;

use Illuminate\Database\Eloquent\Model;

class Permissions extends Model
{
    protected $table='users_permissions';
}
